/*
Navicat MySQL Data Transfer

Source Server         : scx
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test2

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-02-19 23:35:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for visitors
-- ----------------------------
DROP TABLE IF EXISTS `visitors`;
CREATE TABLE `visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(211) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of visitors
-- ----------------------------
INSERT INTO `visitors` VALUES ('1', 'a', '2018-01-01');
INSERT INTO `visitors` VALUES ('2', 'b', '2018-01-02');
INSERT INTO `visitors` VALUES ('3', 'c', '2018-01-03');
INSERT INTO `visitors` VALUES ('4', 'a', '2018-01-02');
INSERT INTO `visitors` VALUES ('5', 'b', '2018-01-01');
INSERT INTO `visitors` VALUES ('6', 'c', '2018-01-02');
INSERT INTO `visitors` VALUES ('7', 'd', '2018-01-04');
INSERT INTO `visitors` VALUES ('8', 'e', '2018-01-04');
INSERT INTO `visitors` VALUES ('9', null, '2018-01-04');
INSERT INTO `visitors` VALUES ('10', 'f', '2018-01-04');
INSERT INTO `visitors` VALUES ('13', null, '2018-01-02');
INSERT INTO `visitors` VALUES ('14', 'g', null);
