/*
Navicat MySQL Data Transfer

Source Server         : scx
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test2

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-02-19 23:34:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for parent_child_relation
-- ----------------------------
DROP TABLE IF EXISTS `parent_child_relation`;
CREATE TABLE `parent_child_relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of parent_child_relation
-- ----------------------------
INSERT INTO `parent_child_relation` VALUES ('1', '101', '102');
INSERT INTO `parent_child_relation` VALUES ('2', '102', '103');
INSERT INTO `parent_child_relation` VALUES ('3', '101', '1001');
INSERT INTO `parent_child_relation` VALUES ('4', '103', '104');
INSERT INTO `parent_child_relation` VALUES ('5', '1001', '1002');
INSERT INTO `parent_child_relation` VALUES ('6', '101', '1003');
INSERT INTO `parent_child_relation` VALUES ('7', '101', '101');
INSERT INTO `parent_child_relation` VALUES ('8', '1003', '101');
