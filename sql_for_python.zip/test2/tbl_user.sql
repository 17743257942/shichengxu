/*
Navicat MySQL Data Transfer

Source Server         : scx
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test2

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-02-19 23:35:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tbl_user
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_user
-- ----------------------------
INSERT INTO `tbl_user` VALUES ('1', 'aa', '刘琬琳');
INSERT INTO `tbl_user` VALUES ('2', 'sdf', '史诚旭');
INSERT INTO `tbl_user` VALUES ('3', 'qwer', 'newpassword');
INSERT INTO `tbl_user` VALUES ('4', 'q', 'q');
INSERT INTO `tbl_user` VALUES ('5', 'xiongda', '1234');
INSERT INTO `tbl_user` VALUES ('7', 'liu', '1234');
INSERT INTO `tbl_user` VALUES ('8', 'liu', '1234');
INSERT INTO `tbl_user` VALUES ('88', 'Bob', 'eeidk');
INSERT INTO `tbl_user` VALUES ('92', 'swagg', '1');
INSERT INTO `tbl_user` VALUES ('93', 'swagg', '1');
INSERT INTO `tbl_user` VALUES ('94', 'swagg', '1');
