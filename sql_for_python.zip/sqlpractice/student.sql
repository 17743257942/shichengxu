/*
Navicat MySQL Data Transfer

Source Server         : scx
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : sqlpractice

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-02-19 23:37:31
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` varchar(511) DEFAULT NULL,
  `sname` varchar(511) DEFAULT NULL,
  `sage` int(11) DEFAULT NULL,
  `ssex` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1001', '学生甲', '12', '男');
INSERT INTO `student` VALUES ('1002', '学生乙', '13', '女');
INSERT INTO `student` VALUES ('1003', '学生丙', '15', '男');
INSERT INTO `student` VALUES ('1004', '学生丁', '22', '女');
INSERT INTO `student` VALUES ('1005', '学生戊', '22', '男');
