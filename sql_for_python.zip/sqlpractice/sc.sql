/*
Navicat MySQL Data Transfer

Source Server         : scx
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : sqlpractice

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-02-19 23:37:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sc
-- ----------------------------
DROP TABLE IF EXISTS `sc`;
CREATE TABLE `sc` (
  `s_id` varchar(511) DEFAULT NULL,
  `c_id` varchar(511) DEFAULT NULL,
  `score` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sc
-- ----------------------------
INSERT INTO `sc` VALUES ('1001', '001', '59');
INSERT INTO `sc` VALUES ('1001', '002', '88');
INSERT INTO `sc` VALUES ('1002', '001', '57');
INSERT INTO `sc` VALUES ('1002', '002', '56');
INSERT INTO `sc` VALUES ('1003', '001', '99');
INSERT INTO `sc` VALUES ('1003', '002', '23');
INSERT INTO `sc` VALUES ('1005', '001', '44');
