/*
Navicat MySQL Data Transfer

Source Server         : scx
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : sqlpractice

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-02-19 23:37:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `id` varchar(511) DEFAULT NULL,
  `cname` varchar(511) DEFAULT NULL,
  `t_id` varchar(511) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('001', '一号课程', '0001');
INSERT INTO `course` VALUES ('002', '二号课程', '0002');
INSERT INTO `course` VALUES ('003', '三号课程', '0003');
