/*
Navicat MySQL Data Transfer

Source Server         : scx
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : sqlpractice

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-02-19 23:37:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `id` varchar(511) DEFAULT NULL,
  `tname` varchar(511) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('0002', '乙老师');
INSERT INTO `teacher` VALUES ('0003', '叶平');
INSERT INTO `teacher` VALUES ('0001', '甲老师');
